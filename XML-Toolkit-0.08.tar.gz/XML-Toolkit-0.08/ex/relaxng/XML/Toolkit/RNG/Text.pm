package XML::Toolkit::RNG::Text;
use Moose;
use namespace::autoclean;
use XML::Toolkit;

1;

__END__
